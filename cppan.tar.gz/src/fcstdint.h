#ifndef _FONTCONFIG_SRC_FCSTDINT_H
#define _FONTCONFIG_SRC_FCSTDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "fontconfig 2.12.6"
/* generated using gnu compiler gcc (GCC) 7.2.1 20170915 (Red Hat 7.2.1-2) */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
